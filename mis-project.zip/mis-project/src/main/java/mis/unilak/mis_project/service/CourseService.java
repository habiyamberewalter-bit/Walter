package mis.unilak.mis_project.service;

import mis.unilak.mis_project.entity.Course;

import java.util.List;

public interface CourseService {
    Course createCourse(Course course);
    Course getCourseById(int id);
    List<Course> getAllCourses();
    void deleteCourseById(int id);
}
