package mis.unilak.mis_project.repository;

import mis.unilak.mis_project.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Integer> {
}
