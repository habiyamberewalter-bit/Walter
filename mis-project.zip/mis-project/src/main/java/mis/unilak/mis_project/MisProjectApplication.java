package mis.unilak.mis_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MisProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MisProjectApplication.class, args);
	}

}
