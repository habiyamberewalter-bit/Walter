package mis.unilak.mis_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MisProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
